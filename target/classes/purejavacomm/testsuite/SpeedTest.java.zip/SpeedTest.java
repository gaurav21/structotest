/*
 * Copyright (c) 2011, Kustaa Nyholm / SpareTimeLabs
 * All rights reserved.
 *
 * Redistribution and use in source and binary forms, with or without modification, 
 * are permitted provided that the following conditions are met:
 *
 * Redistributions of source code must retain the above copyright notice, this list 
 * of conditions and the following disclaimer.
 * 
 * Redistributions in binary form must reproduce the above copyright notice, this 
 * list of conditions and the following disclaimer in the documentation and/or other
 * materials provided with the distribution.
 *  
 * Neither the name of the Kustaa Nyholm or SpareTimeLabs nor the names of its 
 * contributors may be used to endorse or promote products derived from this software 
 * without specific prior written permission.
 * 
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS" 
 * AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED 
 * WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE DISCLAIMED. 
 * IN NO EVENT SHALL THE COPYRIGHT HOLDER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, 
 * INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT 
 * NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, 
 * OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, 
 * WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) 
 * ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY
 * OF SUCH DAMAGE.
 */
package purejavacomm.testsuite;

import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.util.Arrays;

import purejavacomm.CommPortIdentifier;
import purejavacomm.SerialPort;
import purejavacomm.SerialPortEvent;
import purejavacomm.SerialPortEventListener;

public class SpeedTest {
	static volatile SerialPort port = null;
	static volatile boolean rxdone;
	static volatile boolean txdone;
	static volatile int messageSize;
	static volatile int messageCount;
	static volatile byte[] txbuffer;
	static volatile byte[] rxbuffer;
	static volatile long T0;
	static volatile long T1;
	static volatile long N;

	public static void main(String[] args) throws Exception {
		try {

			//CommPortIdentifier portIdent = CommPortIdentifier.getPortIdentifier("tty.usbserial-FTOXM3NX");
			CommPortIdentifier portIdent = CommPortIdentifier.getPortIdentifier("ttyUSB0");
			port = (SerialPort) portIdent.open("speedtest", 1000);
			messageSize = 200;
			messageCount = 500;

			port.setSerialPortParams(230000, 8, 1, 0);
			port.enableReceiveThreshold(messageSize);
			port.enableReceiveTimeout(1000);

			txbuffer = new byte[messageSize];
			rxbuffer = new byte[messageSize];
			for (int i = 0; i < messageSize; i++)
				txbuffer[i] = (byte) ((i & 0x1F) + 'A');

			Thread txthread = new Thread(new Runnable() {
				public void run() {
					try {
						OutputStream out = port.getOutputStream();
						int txCount = 0;
						if (T0 == 0)
							T0 = System.nanoTime();
						while (txCount++ < messageCount) {
							out.write(txbuffer);
							N += txbuffer.length;
						}

					} catch (Exception e) {
						e.printStackTrace();
					} finally {
						txdone = true;
					}
				}
			});

			Thread rxthread = new Thread(new Runnable() {
				public void run() {
					try {
						InputStream in = port.getInputStream();
						byte[] rxbuffer = new byte[messageSize];

						int rxCount = 0;
						while (rxCount++ < messageCount) {
							int n = in.read(rxbuffer);
							if (n != messageSize)
								throw new IOException("" + n + " != " + messageSize);
							for (int i = 0; i < messageSize; i++)
								if (rxbuffer[i] != txbuffer[i])
									throw new IOException(String.format(" rxbuffer[%d] = 0x%02X,txbuffer[%d]=0x%02X, message %d ", i, 0xFF & rxbuffer[i], i, 0xFF & txbuffer[i], rxCount));
							//System.out.println("Message received " + rxCount);
						}
						T1=System.nanoTime();
						System.out.println("Done, average speed was "+(int)((N*10/((T1-T0)/1000000000.0)))+" baud");

					} catch (IOException e) {
						e.printStackTrace();

					} finally {
						rxdone = true;
					}
				}
			});

			rxthread.setPriority(Thread.MAX_PRIORITY);
			txthread.setPriority(Thread.MAX_PRIORITY);
			rxthread.start();
			txthread.start();
			while (!txdone || !rxdone) {
				System.out.println("Dave, I'm feeling sleepy...");
				Thread.sleep(100);
			}

		} finally {
			if (port != null)
				port.close();
		}

	}
}
